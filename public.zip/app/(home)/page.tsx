import HeroSection from "../_components/HeroSection";
import ProductSection from "../_components/ProductSection";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <ProductSection />
    </div>
  );
}
